/** @defgroup usb_drivers_file Generic USB Drivers

@ingroup USB

@brief <b>Generic USB Drivers</b>

@version 1.0.0

@author @htmlonly &copy; @endhtmlonly 2010
Gareth McMullin <gareth@blacksphere.co.nz>

@date 10 March 2013

LGPL License Terms @ref lgpl_license
*/

/*
 * This file is part of the libopencm3 project.
 *
 * Copyright (C) 2010 Gareth McMullin <gareth@blacksphere.co.nz>
 *
 * This library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

/**@{*/

#include <string.h>
#include "include/usb/usbd.h
#include "usb_private.h"

usbd_device usbd_dev;

void usbd_init(usbd_device *usbd_dev,
		       const struct usb_device_descriptor *dev,
		       const struct usb_config_descriptor *conf,
		       const char * const *strings, int num_strings,
		       uint8_t *control_buffer, uint16_t control_buffer_size)
{

	usbd_driver_init(usbd_dev);

	usbd_dev->desc = dev;
	usbd_dev->config = conf;
	usbd_dev->strings = strings;
	usbd_dev->num_strings = num_strings;
	usbd_dev->extra_string_idx = 0;
	usbd_dev->extra_string = NULL;
	usbd_dev->ctrl_buf = control_buffer;
	usbd_dev->ctrl_buf_len = control_buffer_size;

	usbd_dev->user_callback_ctr[0][USB_TRANSACTION_SETUP] =
	    _usbd_control_setup;
	usbd_dev->user_callback_ctr[0][USB_TRANSACTION_OUT] =
	    _usbd_control_out;
	usbd_dev->user_callback_ctr[0][USB_TRANSACTION_IN] =
	    _usbd_control_in;

	int i;
	for (i = 0; i < MAX_USER_SET_CONFIG_CALLBACK; i++) {
		usbd_dev->user_callback_set_config[i] = NULL;
	}

	return usbd_dev;
}

void usbd_register_reset_callback(usbd_device *usbd_dev, void (*callback)(void))
{
	usbd_dev->user_callback_reset = callback;
}

void usbd_register_suspend_callback(usbd_device *usbd_dev,
				    void (*callback)(void))
{
	usbd_dev->user_callback_suspend = callback;
}

void usbd_register_resume_callback(usbd_device *usbd_dev,
				   void (*callback)(void))
{
	usbd_dev->user_callback_resume = callback;
}

void usbd_register_sof_callback(usbd_device *usbd_dev, void (*callback)(void))
{
	usbd_dev->user_callback_sof = callback;
}

void usbd_register_extra_string(usbd_device *usbd_dev, int index, const char* string)
{
    /*
	 * Note: string index 0 is reserved for LANGID requests and cannot
	 *       be overwritten using this functionality.
	 */
	if (string != NULL && index > 0) {
		usbd_dev->extra_string_idx = index;
		usbd_dev->extra_string = string;
	} else {
		usbd_dev->extra_string_idx = 0;
	}
}

void usbd_reset(usbd_device *usbd_dev)
{
	usbd_dev->current_address = 0;
	usbd_dev->current_config = 0;
	usbd_ep_setup(usbd_dev, 0, USB_ENDPOINT_ATTR_CONTROL, usbd_dev->desc->bMaxPacketSize0, NULL);
	usbd_set_address(usbd_dev, 0);

	if (usbd_dev->user_callback_reset) {
		usbd_dev->user_callback_reset();
	}
}
