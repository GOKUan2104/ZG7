/**
  ******************************************************************************
  * @file      startup_stm32f411xe.s
  * @author    MCD Application Team
  * @version   V2.5.0
  * @date      22-April-2015
  * @brief     STM32F411xExx Devices vector table for GCC based toolchains. 
  *            This module performs:
  *                - Set the initial SP
  *                - Set the initial PC == Reset_Handler,
  *                - Set the vector table entries with the exceptions ISR address
  *                - Branches to main in the C library (which eventually
  *                  calls main()).
  *            After Reset the Cortex-M4 processor is in Thread mode,
  *            priority is Privileged, and the Stack is set to Main.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2016 STMicroelectronics</center></h2>
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
    
		.syntax unified
		.cpu cortex-m4
		.fpu softvfp
		.thumb

		.global		g_pfnVectors
		.global		Default_Handler
		.global		_exit

/**
 * @brief  This is the code that gets called when the processor first
 *          starts execution following a reset event. Only the absolutely
 *          necessary set is performed, after which the application
 *          supplied main() routine is called. 
 * @param  None
 * @retval : None
*/

		.section  .text.Reset_Handler
		.weak	Reset_Handler
		.type	Reset_Handler, %function


Reset_Handler:
		// Copy the data segment initializers from flash to SRAM 
		ldr		r0, =_sidata
		ldr		r1, =_sdata
		ldr		r2, =_edata
dloop:	cmp		r1, r2
		beq		dloope
		ldr		r4, [r0], #4
		str		r4, [r1], #4
		b		dloop
		
dloope:
		// Zero fill the bss segment
		ldr		r0, =_sbss
		ldr		r1, =_ebss
		mov		r2, #0
bloop:	cmp		r0, r1
		beq		bloope
		str		r2, [r0], #4
		b		bloop
bloope:		
		// Call the clock system intitialization function.
		bl		SystemInit
		
		// Call static constructors
		bl		__libc_init_array
		
		// Call the application's entry point
		bl		main
exit:	b		exit

		.size  Reset_Handler, .-Reset_Handler

/**
 * @brief  This is the code that gets called when the processor receives an 
 *         unexpected interrupt.  This simply enters an infinite loop, preserving
 *         the system state for examination by a debugger.
 * @param  None     
 * @retval None       
*/
		.section .text.Default_Handler,"ax",%progbits
Default_Handler:
Infinite_Loop:
		b		Infinite_Loop
		
		.size	Default_Handler, .-Default_Handler
		
		
/******************************************************************************
*
* The minimal vector table for a Cortex M3. Note that the proper constructs
* must be placed on this to ensure that it ends up at physical address
* 0x0000.0000.
* 
*******************************************************************************/
		.section  .isr_vector,"a",%progbits
		.type  g_pfnVectors, %object
		.size  g_pfnVectors, .-g_pfnVectors
    
g_pfnVectors:
		.word	_estack							/* MSP reset value */
		.word	Reset_Handler					/* Reset handler */
		.word	NMI_Handler						/* Non Maskable Interrupt */
		.word	HardFault_Handler				/* Hardware fault */
		.word	MemManage_Handler
		.word	BusFault_Handler
		.word	UsageFault_Handler
		.word	0
		.word	0
		.word	0
		.word	0
		.word	SVC_Handler
		.word	DebugMon_Handler
		.word	0
		.word	PendSV_Handler
		.word	SysTick_Handler
  
		/* External Interrupts */
		.word	WWDG_IRQHandler                   /* Window WatchDog              */                                        
		.word	PVD_IRQHandler                    /* PVD through EXTI Line detection */                        
		.word	TAMP_STAMP_IRQHandler             /* Tamper and TimeStamps through the EXTI line */            
		.word	RTC_WKUP_IRQHandler               /* RTC Wakeup through the EXTI line */                      
		.word	FLASH_IRQHandler                  /* FLASH                        */                                          
		.word	RCC_IRQHandler                    /* RCC                          */                                            
		.word	EXTI0_IRQHandler                  /* EXTI Line0                   */                        
		.word	EXTI1_IRQHandler                  /* EXTI Line1                   */                          
		.word	EXTI2_IRQHandler                  /* EXTI Line2                   */                          
		.word	EXTI3_IRQHandler                  /* EXTI Line3                   */                          
		.word	EXTI4_IRQHandler                  /* EXTI Line4                   */                          
		.word	DMA1_Stream0_IRQHandler           /* DMA1 Stream 0                */                  
		.word	DMA1_Stream1_IRQHandler           /* DMA1 Stream 1                */                   
		.word	DMA1_Stream2_IRQHandler           /* DMA1 Stream 2                */                   
		.word	DMA1_Stream3_IRQHandler           /* DMA1 Stream 3                */                   
		.word	DMA1_Stream4_IRQHandler           /* DMA1 Stream 4                */                   
		.word	DMA1_Stream5_IRQHandler           /* DMA1 Stream 5                */                   
		.word	DMA1_Stream6_IRQHandler           /* DMA1 Stream 6                */                   
		.word	ADC_IRQHandler                    /* ADC1, ADC2 and ADC3s         */                   
		.word	0               				  /* Reserved                      */                         
		.word	0              					  /* Reserved                     */                          
		.word	0                                 /* Reserved                     */                          
		.word	0                                 /* Reserved                     */                          
		.word	EXTI9_5_IRQHandler                /* External Line[9:5]s          */                          
		.word	TIM1_BRK_TIM9_IRQHandler          /* TIM1 Break and TIM9          */         
		.word	TIM1_UP_TIM10_IRQHandler          /* TIM1 Update and TIM10        */         
		.word	TIM1_TRG_COM_TIM11_IRQHandler     /* TIM1 Trigger and Commutation and TIM11 */
		.word	TIM1_CC_IRQHandler                /* TIM1 Capture Compare         */                          
		.word	TIM2_IRQHandler                   /* TIM2                         */                   
		.word	TIM3_IRQHandler                   /* TIM3                         */                   
		.word	TIM4_IRQHandler                   /* TIM4                         */                   
		.word	I2C1_EV_IRQHandler                /* I2C1 Event                   */                          
		.word	I2C1_ER_IRQHandler                /* I2C1 Error                   */                          
		.word	I2C2_EV_IRQHandler                /* I2C2 Event                   */                          
		.word	I2C2_ER_IRQHandler                /* I2C2 Error                   */                            
		.word	SPI1_IRQHandler                   /* SPI1                         */                   
		.word	SPI2_IRQHandler                   /* SPI2                         */                   
		.word	USART1_IRQHandler                 /* USART1                       */                   
		.word	USART2_IRQHandler                 /* USART2                       */                   
		.word	0               				  /* Reserved                       */                   
		.word	EXTI15_10_IRQHandler              /* External Line[15:10]s        */                          
		.word	RTC_Alarm_IRQHandler              /* RTC Alarm (A and B) through EXTI Line */                 
		.word	OTG_FS_WKUP_IRQHandler            /* USB OTG FS Wakeup through EXTI line */                       
		.word	0                                 /* Reserved     				  */         
		.word	0                                 /* Reserved       			  */         
		.word	0                                 /* Reserved 					  */
		.word	0                                 /* Reserved                     */                          
		.word	DMA1_Stream7_IRQHandler           /* DMA1 Stream7                 */                          
		.word	0                                 /* Reserved                     */                   
		.word	SDIO_IRQHandler                   /* SDIO                         */                   
		.word	TIM5_IRQHandler                   /* TIM5                         */                   
		.word	SPI3_IRQHandler                   /* SPI3                         */                   
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */
		.word	DMA2_Stream0_IRQHandler           /* DMA2 Stream 0                */                   
		.word	DMA2_Stream1_IRQHandler           /* DMA2 Stream 1                */                   
		.word	DMA2_Stream2_IRQHandler           /* DMA2 Stream 2                */                   
		.word	DMA2_Stream3_IRQHandler           /* DMA2 Stream 3                */                   
		.word	DMA2_Stream4_IRQHandler           /* DMA2 Stream 4                */                   
		.word	0                    			  /* Reserved                     */                   
		.word	0              					  /* Reserved                     */                     
		.word	0              					  /* Reserved                     */                          
		.word	0             					  /* Reserved                     */                          
		.word	0              					  /* Reserved                     */                          
		.word	0              					  /* Reserved                     */                          
		.word	OTG_FS_IRQHandler                 /* USB OTG FS                   */                   
		.word	DMA2_Stream5_IRQHandler           /* DMA2 Stream 5                */                   
		.word	DMA2_Stream6_IRQHandler           /* DMA2 Stream 6                */                   
		.word	DMA2_Stream7_IRQHandler           /* DMA2 Stream 7                */                   
		.word	USART6_IRQHandler                 /* USART6                       */                    
		.word	I2C3_EV_IRQHandler                /* I2C3 event                   */                          
		.word	I2C3_ER_IRQHandler                /* I2C3 error                   */                          
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */                         
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */
		.word	FPU_IRQHandler                    /* FPU                          */
		.word	0                                 /* Reserved                     */                   
		.word	0                                 /* Reserved                     */
		.word	SPI4_IRQHandler                   /* SPI4                         */
		.word	SPI5_IRQHandler                   /* SPI5                         */  
                   
/*******************************************************************************
*
* Provide weak aliases for each Exception handler to the Default_Handler. 
* As they are weak aliases, any function with the same name will override 
* this definition.
* 
*******************************************************************************/
   .weak      NMI_Handler
   .thumb_set NMI_Handler,Default_Handler
  
   .weak      HardFault_Handler
   .thumb_set HardFault_Handler,Default_Handler
  
   .weak      MemManage_Handler
   .thumb_set MemManage_Handler,Default_Handler
  
   .weak      BusFault_Handler
   .thumb_set BusFault_Handler,Default_Handler

   .weak      UsageFault_Handler
   .thumb_set UsageFault_Handler,Default_Handler

   .weak      SVC_Handler
   .thumb_set SVC_Handler,Default_Handler

   .weak      DebugMon_Handler
   .thumb_set DebugMon_Handler,Default_Handler

   .weak      PendSV_Handler
   .thumb_set PendSV_Handler,Default_Handler

   .weak      SysTick_Handler
   .thumb_set SysTick_Handler,Default_Handler              
  
   .weak      WWDG_IRQHandler                   
   .thumb_set WWDG_IRQHandler,Default_Handler      
                  
   .weak      PVD_IRQHandler      
   .thumb_set PVD_IRQHandler,Default_Handler
               
   .weak      TAMP_STAMP_IRQHandler            
   .thumb_set TAMP_STAMP_IRQHandler,Default_Handler
            
   .weak      RTC_WKUP_IRQHandler                  
   .thumb_set RTC_WKUP_IRQHandler,Default_Handler
            
   .weak      FLASH_IRQHandler         
   .thumb_set FLASH_IRQHandler,Default_Handler
                  
   .weak      RCC_IRQHandler      
   .thumb_set RCC_IRQHandler,Default_Handler
                  
   .weak      EXTI0_IRQHandler         
   .thumb_set EXTI0_IRQHandler,Default_Handler
                  
   .weak      EXTI1_IRQHandler         
   .thumb_set EXTI1_IRQHandler,Default_Handler
                     
   .weak      EXTI2_IRQHandler         
   .thumb_set EXTI2_IRQHandler,Default_Handler 
                 
   .weak      EXTI3_IRQHandler         
   .thumb_set EXTI3_IRQHandler,Default_Handler
                        
   .weak      EXTI4_IRQHandler         
   .thumb_set EXTI4_IRQHandler,Default_Handler
                  
   .weak      DMA1_Stream0_IRQHandler               
   .thumb_set DMA1_Stream0_IRQHandler,Default_Handler
         
   .weak      DMA1_Stream1_IRQHandler               
   .thumb_set DMA1_Stream1_IRQHandler,Default_Handler
                  
   .weak      DMA1_Stream2_IRQHandler               
   .thumb_set DMA1_Stream2_IRQHandler,Default_Handler
                  
   .weak      DMA1_Stream3_IRQHandler               
   .thumb_set DMA1_Stream3_IRQHandler,Default_Handler 
                 
   .weak      DMA1_Stream4_IRQHandler              
   .thumb_set DMA1_Stream4_IRQHandler,Default_Handler
                  
   .weak      DMA1_Stream5_IRQHandler               
   .thumb_set DMA1_Stream5_IRQHandler,Default_Handler
                  
   .weak      DMA1_Stream6_IRQHandler               
   .thumb_set DMA1_Stream6_IRQHandler,Default_Handler
                  
   .weak      ADC_IRQHandler      
   .thumb_set ADC_IRQHandler,Default_Handler
            
   .weak      EXTI9_5_IRQHandler   
   .thumb_set EXTI9_5_IRQHandler,Default_Handler
            
   .weak      TIM1_BRK_TIM9_IRQHandler            
   .thumb_set TIM1_BRK_TIM9_IRQHandler,Default_Handler
            
   .weak      TIM1_UP_TIM10_IRQHandler            
   .thumb_set TIM1_UP_TIM10_IRQHandler,Default_Handler
      
   .weak      TIM1_TRG_COM_TIM11_IRQHandler      
   .thumb_set TIM1_TRG_COM_TIM11_IRQHandler,Default_Handler
      
   .weak      TIM1_CC_IRQHandler   
   .thumb_set TIM1_CC_IRQHandler,Default_Handler
                  
   .weak      TIM2_IRQHandler            
   .thumb_set TIM2_IRQHandler,Default_Handler
                  
   .weak      TIM3_IRQHandler            
   .thumb_set TIM3_IRQHandler,Default_Handler
                  
   .weak      TIM4_IRQHandler            
   .thumb_set TIM4_IRQHandler,Default_Handler
                  
   .weak      I2C1_EV_IRQHandler   
   .thumb_set I2C1_EV_IRQHandler,Default_Handler
                     
   .weak      I2C1_ER_IRQHandler   
   .thumb_set I2C1_ER_IRQHandler,Default_Handler
                     
   .weak      I2C2_EV_IRQHandler   
   .thumb_set I2C2_EV_IRQHandler,Default_Handler
                  
   .weak      I2C2_ER_IRQHandler   
   .thumb_set I2C2_ER_IRQHandler,Default_Handler
                           
   .weak      SPI1_IRQHandler            
   .thumb_set SPI1_IRQHandler,Default_Handler
                        
   .weak      SPI2_IRQHandler            
   .thumb_set SPI2_IRQHandler,Default_Handler
                  
   .weak      USART1_IRQHandler      
   .thumb_set USART1_IRQHandler,Default_Handler
                     
   .weak      USART2_IRQHandler      
   .thumb_set USART2_IRQHandler,Default_Handler
                                  
   .weak      EXTI15_10_IRQHandler               
   .thumb_set EXTI15_10_IRQHandler,Default_Handler
               
   .weak      RTC_Alarm_IRQHandler               
   .thumb_set RTC_Alarm_IRQHandler,Default_Handler
            
   .weak      OTG_FS_WKUP_IRQHandler         
   .thumb_set OTG_FS_WKUP_IRQHandler,Default_Handler
            
   .weak      DMA1_Stream7_IRQHandler               
   .thumb_set DMA1_Stream7_IRQHandler,Default_Handler
                     
   .weak      SDIO_IRQHandler            
   .thumb_set SDIO_IRQHandler,Default_Handler
                     
   .weak      TIM5_IRQHandler            
   .thumb_set TIM5_IRQHandler,Default_Handler
                     
   .weak      SPI3_IRQHandler            
   .thumb_set SPI3_IRQHandler,Default_Handler
                     
   .weak      DMA2_Stream0_IRQHandler               
   .thumb_set DMA2_Stream0_IRQHandler,Default_Handler
               
   .weak      DMA2_Stream1_IRQHandler               
   .thumb_set DMA2_Stream1_IRQHandler,Default_Handler
                  
   .weak      DMA2_Stream2_IRQHandler               
   .thumb_set DMA2_Stream2_IRQHandler,Default_Handler
            
   .weak      DMA2_Stream3_IRQHandler               
   .thumb_set DMA2_Stream3_IRQHandler,Default_Handler
            
   .weak      DMA2_Stream4_IRQHandler               
   .thumb_set DMA2_Stream4_IRQHandler,Default_Handler
            
   .weak      OTG_FS_IRQHandler      
   .thumb_set OTG_FS_IRQHandler,Default_Handler
                     
   .weak      DMA2_Stream5_IRQHandler               
   .thumb_set DMA2_Stream5_IRQHandler,Default_Handler
                  
   .weak      DMA2_Stream6_IRQHandler               
   .thumb_set DMA2_Stream6_IRQHandler,Default_Handler
                  
   .weak      DMA2_Stream7_IRQHandler               
   .thumb_set DMA2_Stream7_IRQHandler,Default_Handler
                  
   .weak      USART6_IRQHandler      
   .thumb_set USART6_IRQHandler,Default_Handler
                        
   .weak      I2C3_EV_IRQHandler   
   .thumb_set I2C3_EV_IRQHandler,Default_Handler
                        
   .weak      I2C3_ER_IRQHandler   
   .thumb_set I2C3_ER_IRQHandler,Default_Handler
                        
   .weak      FPU_IRQHandler                  
   .thumb_set FPU_IRQHandler,Default_Handler  

   .weak      SPI4_IRQHandler                  
   .thumb_set SPI4_IRQHandler,Default_Handler

   .weak      SPI5_IRQHandler                  
   .thumb_set SPI5_IRQHandler,Default_Handler    

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

