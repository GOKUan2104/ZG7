#include "sw.h"
#include "stm32f4xx_hal_gpio.h"

// SW_UP     --> PA4
// SW_DOWN   --> PB0
// SW_CENTER --> PB5
// SW_RIGHT  --> PC0
// SW_LEFT   --> PC1
//====================================================================
uint32_t sw_right_raw(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_left_raw(void)
{
	return 0; // A COMPLETER);
}
//====================================================================
uint32_t sw_center_raw(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_up_raw(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_down_raw(void)
{
	return 0; // A COMPLETER
}
//====================================================================
//{CENTER, DOWN, UP, LEFT, RIGHT}
uint32_t sw_input_raw(void)
{
	return 0; // A COMPLETER
}
//====================================================================
//====================================================================
uint32_t sw_right_debounce(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_left_debounce(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_up_debounce(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_down_debounce(void)
{
	return 0; // A COMPLETER
}
//====================================================================
uint32_t sw_center_debounce(void)
{
	return 0; // A COMPLETER
}
//====================================================================





