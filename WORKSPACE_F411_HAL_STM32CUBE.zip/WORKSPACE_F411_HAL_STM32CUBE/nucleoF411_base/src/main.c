/****************************************************************
 * file    main_pdm.c
 * author  Eric Boucharé (base), completed for PC streaming
 * version v1.1.0
 * brief   Acquisition de 2 microphones PDM (X-NUCLEO-CCA02M2),
 *         conversion PDM -> PCM 16 bits, puis envoi du signal PCM
 *         vers le PC par l'USART2 (port serie virtuel de la ST-LINK).
 *
 *         Cote PC : tools/capture.py reconstruit le signal audio,
 *         l'enregistre en .wav et trace la forme d'onde / le spectre.
 ****************************************************************/


/* Includes ------------------------------------------------------------------*/
#include "pdm/cca02m2/cca02m2_audio.h"
#include "io.h"
#include "stm32f4xx_hal_uart.h"

#define CHANNEL_NB				2
#define SAMPLING_FREQ			16000
#define SAMPLING_RES			16
#define VOLUME					64U

/* 16 kHz x 2 voies x 16 bits = 64 ko/s, soit 68 octets/ms avec l'en-tete
 * -> 680 kbit/s utiles : 921600 bauds passent (74 % de charge) */
#define UART_BAUD				921600

/* Nombre d'echantillons PCM (toutes voies) par tranche de N_MS_PER_INTERRUPT ms */
#define PCM_SAMPLES				(CHANNEL_NB*SAMPLING_FREQ/1000*N_MS_PER_INTERRUPT)

/* Trame envoyee au PC, une par tranche de N_MS_PER_INTERRUPT ms :
 *
 *   +------+------+-----+----------+---------------------------------------+
 *   | 0xA5 | 0x5A | seq | channels |  PCM_SAMPLES x int16 little endian    |
 *   +------+------+-----+----------+---------------------------------------+
 *     sync0  sync1  n° de   nb de     voies entrelacees : L R L R L R ...
 *                   tranche voies
 *
 * seq (modulo 256) permet au PC de detecter les tranches perdues. */
#define FRAME_SYNC0				0xA5
#define FRAME_SYNC1				0x5A

typedef struct {
	uint8_t		sync0;
	uint8_t		sync1;
	uint8_t		seq;
	uint8_t		channels;
	int16_t		pcm[PCM_SAMPLES];
} frame_t;

/* verification a la compilation : pas de padding dans la trame */
typedef char frame_size_check[(sizeof(frame_t) == 4 + 2*PCM_SAMPLES) ? 1 : -1];

volatile int flag = 0;
volatile uint8_t chunk_cnt = 0;

uint8_t pdm_buf[MAX_PDMBUFSZ];
frame_t frame;

void pdm_buf_filled_cb()
{
	chunk_cnt++;
	flag = 1;
}

int main(void)
{
	AUDIO_IN_Init_t MicParams = {
		.SampleRate = SAMPLING_FREQ,
		.BitsPerSample = SAMPLING_RES,
		.ChannelsNbr = CHANNEL_NB,
		.Volume = VOLUME,
		.pdm_buf = pdm_buf,
		.cb = pdm_buf_filled_cb
	};
	
	/* USART2 : PA2 (Tx) / PA3 (Rx), relie au port serie virtuel de la ST-LINK */
	uart_init(_USART2, UART_BAUD, UART_8N1);
	
	frame.sync0    = FRAME_SYNC0;
	frame.sync1    = FRAME_SYNC1;
	frame.channels = CHANNEL_NB;
	
	AUDIO_IN_Init(&MicParams);
	AUDIO_IN_Record();
	
	while (1) {
		if (flag) {
			frame.seq = chunk_cnt;
			flag = 0;
			
			/* PDM -> PCM : 16 echantillons par voie (1 ms a 16 kHz) */
			AUDIO_IN_PDMToPCM(pdm_buf, (uint16_t*)frame.pcm);
			
			/* envoi de la trame au PC (la file d'attente Tx de uart.c est
			 * vidangee par interruption, on n'attend donc pas la fin de l'envoi) */
			uart_write(_USART2, (uint8_t*)&frame, sizeof(frame));
		}
	}
	
	return 0;
}
