#include "stm32f4xx_it.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_cortex.h"
#include "stm32f4xx_hal_gpio.h"
#include "stm32f4xx_hal_tim.h"
#include "stm32f4xx_hal_uart.h"
#include "pdm/cca02m2/pdm_platform.h"

extern TIM_HandleTypeDef htim5;
extern UART_HandleTypeDef huart2;

//===========================================================
void SysTick_Handler(void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
#ifdef USE_RTOS_SYSTICK
	osSystickHandler();
#endif
}

//===========================================================
void TIM5_IRQHandler(void)
{
  HAL_TIM_IRQHandler(&htim5);
}
//===========================================================
void USART2_IRQHandler(void)
{
  HAL_USART_IRQHandler(&huart2);
}
//===========================================================
void DMA1_Stream3_IRQHandler(void)
{
	pdm_dma_irq_handler();
}
//===========================================================


