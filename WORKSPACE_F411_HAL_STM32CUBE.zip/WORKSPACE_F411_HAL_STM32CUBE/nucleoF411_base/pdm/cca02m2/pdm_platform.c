#include <stdint.h>
#include "pdm_platform.h"
#include "stm32f4xx_hal_gpio.h"
#include "stm32f4xx_hal_gpio_ex.h"
#include "stm32f4xx_ll_rcc.h"

static PDM_DMA_Stream_t pdm_dma_stream;
static uint32_t pdm_i2s_clock;

uint32_t pdm_i2s_clock_config(const I2SClkCfg_t *config)
{
    uint32_t input_clock;

    RCC->CR &= ~RCC_CR_PLLI2SON;
    while ((RCC->CR & RCC_CR_PLLI2SRDY) != 0U) {}

    RCC->PLLI2SCFGR = (RCC->PLLI2SCFGR & ~((0x1FFU << 6) | (0x7U << 28))) |
                      ((uint32_t)config->N << 6) |
                      ((uint32_t)config->R << 28);
    RCC->CR |= RCC_CR_PLLI2SON;
    while ((RCC->CR & RCC_CR_PLLI2SRDY) == 0U) {}

    input_clock = ((RCC->PLLCFGR & RCC_PLLCFGR_PLLSRC) != 0U) ? 8000000U : 16000000U;
    pdm_i2s_clock = (input_clock / (RCC->PLLCFGR & RCC_PLLCFGR_PLLM)) * config->N / config->R;
    return pdm_i2s_clock;
}

uint32_t pdm_i2s_get_clock(void)
{
    return pdm_i2s_clock;
}

void pdm_i2s_gpio_init(void)
{
    GPIO_InitTypeDef gpio_init;

    __GPIOB_CLK_ENABLE();
    gpio_init.Pin = GPIO_PIN_13 | GPIO_PIN_15;
    gpio_init.Mode = GPIO_MODE_AF_PP;
    gpio_init.Pull = GPIO_NOPULL;
    gpio_init.Speed = GPIO_SPEED_HIGH;
    gpio_init.Alternate = GPIO_AF5_SPI2;
    HAL_GPIO_Init(GPIOB, &gpio_init);
}

void pdm_dual_mic_clock_init(void)
{
    GPIO_InitTypeDef gpio_init;

    __GPIOB_CLK_ENABLE();
    __TIM3_CLK_ENABLE();

    gpio_init.Pin = GPIO_PIN_4 | GPIO_PIN_5;
    gpio_init.Mode = GPIO_MODE_AF_PP;
    gpio_init.Pull = GPIO_NOPULL;
    gpio_init.Speed = GPIO_SPEED_HIGH;
    gpio_init.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOB, &gpio_init);

    TIM3->PSC = 0U;
    TIM3->ARR = 1U;
    TIM3->CCMR1 = (1U << 0) | (3U << 12);
    TIM3->CCER = TIM_CCER_CC1E | TIM_CCER_CC2E;
    TIM3->SMCR = (5U << 4) | (7U << 0);
    TIM3->CR1 = TIM_CR1_CEN;
}

PDM_DMA_Stream_t *pdm_dma_stream_init(DMA_t *controller,
                                      uint32_t stream_number,
                                      const DMAEndPoint_t *peripheral,
                                      const DMAEndPoint_t *memory,
                                      uint32_t priority,
                                      PDM_DMA_Callback_t callback)
{
    DMA_Stream_t *hardware;

    if ((controller != DMA1) || (stream_number != 3U)) {
        return (PDM_DMA_Stream_t *)0;
    }

    RCC->AHB1ENR |= (1U << 21);
    hardware = DMA1_Stream3;
    hardware->CR = 0U;
    hardware->PAR = (uint32_t)peripheral->addr0;
    hardware->M0AR = (uint32_t)memory->addr0;
    hardware->M1AR = (uint32_t)memory->addr1;
    hardware->FCR = 0U;
    pdm_dma_stream.hardware = hardware;
    pdm_dma_stream.callback = callback;

    (void)priority;
    return &pdm_dma_stream;
}

void pdm_dma_start(PDM_DMA_Stream_t *stream, uint16_t length)
{
    DMA_Stream_t *hardware = stream->hardware;

    hardware->CR &= ~DMA_SxCR_EN;
    DMA1->LIFCR = DMA_LIFCR_CFEIF3 | DMA_LIFCR_CDMEIF3 |
                  DMA_LIFCR_CTEIF3 | DMA_LIFCR_CHTIF3 |
                  DMA_LIFCR_CTCIF3;
    hardware->NDTR = length;
    hardware->CR = (0U << 25) | (3U << 16) | DMA_SxCR_MSIZE_0 |
                   DMA_SxCR_PSIZE_0 | DMA_SxCR_MINC | DMA_SxCR_CIRC |
                   DMA_SxCR_DBM | DMA_SxCR_HTIE | DMA_SxCR_TCIE |
                   DMA_SxCR_TEIE;
    NVIC_SetPriority(DMA1_Stream3_IRQn, 6U);
    NVIC_EnableIRQ(DMA1_Stream3_IRQn);
    hardware->CR |= DMA_SxCR_EN;
}

void pdm_dma_stop(PDM_DMA_Stream_t *stream)
{
    stream->hardware->CR &= ~DMA_SxCR_EN;
}

void pdm_dma_irq_handler(void)
{
    uint32_t status = DMA1->LISR;
    DMA_Stream_t *hardware = pdm_dma_stream.hardware;

    DMA1->LIFCR = DMA_LIFCR_CFEIF3 | DMA_LIFCR_CDMEIF3 |
                  DMA_LIFCR_CTEIF3 | DMA_LIFCR_CHTIF3 |
                  DMA_LIFCR_CTCIF3;

    if ((hardware != (DMA_Stream_t *)0) && (pdm_dma_stream.callback != (PDM_DMA_Callback_t)0)) {
        if ((status & DMA_LISR_HTIF3) != 0U) {
            pdm_dma_stream.callback(3U, 1U);
        }
        if ((status & DMA_LISR_TCIF3) != 0U) {
            pdm_dma_stream.callback(3U, 0U);
        }
    }
}
