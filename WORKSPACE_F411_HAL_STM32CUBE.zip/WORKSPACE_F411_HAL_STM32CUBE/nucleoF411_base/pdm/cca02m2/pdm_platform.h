#ifndef PDM_PLATFORM_H
#define PDM_PLATFORM_H

#include <stdint.h>
#include "board.h"

typedef struct {
    uint8_t M;
    uint16_t N;
    uint8_t R;
} I2SClkCfg_t;

typedef void (*PDM_DMA_Callback_t)(uint32_t stream, uint32_t buffer_id);

typedef struct {
    void *addr0;
    void *addr1;
    int channel;
} DMAEndPoint_t;

typedef struct {
    DMA_Stream_t *hardware;
    PDM_DMA_Callback_t callback;
} PDM_DMA_Stream_t;

#define SPI2_GPIO_PORT GPIOB
#define SPI2_GPIO_PINS (GPIO_PIN_13 | GPIO_PIN_15)
#define STRM_PRIO_HIGH 3U

uint32_t pdm_i2s_clock_config(const I2SClkCfg_t *config);
uint32_t pdm_i2s_get_clock(void);
void pdm_i2s_gpio_init(void);
void pdm_dual_mic_clock_init(void);
PDM_DMA_Stream_t *pdm_dma_stream_init(DMA_t *controller,
                                      uint32_t stream_number,
                                      const DMAEndPoint_t *peripheral,
                                      const DMAEndPoint_t *memory,
                                      uint32_t priority,
                                      PDM_DMA_Callback_t callback);
void pdm_dma_start(PDM_DMA_Stream_t *stream, uint16_t length);
void pdm_dma_stop(PDM_DMA_Stream_t *stream);
void pdm_dma_irq_handler(void);

#endif
