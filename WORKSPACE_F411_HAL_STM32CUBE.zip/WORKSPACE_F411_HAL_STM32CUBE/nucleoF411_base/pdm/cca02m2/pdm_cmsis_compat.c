#include <stdint.h>

#include "stm32f411xe.h"
#include "cmsis/arm_math.h"

arm_status arm_fir_decimate_init_q15(arm_fir_decimate_instance_q15 *state,
                                     uint16_t num_taps,
                                     uint8_t decimation,
                                     q15_t *coefficients,
                                     q15_t *buffer,
                                     uint32_t block_size)
{
    if ((decimation == 0U) || ((block_size % decimation) != 0U)) {
        return ARM_MATH_LENGTH_ERROR;
    }

    state->M = decimation;
    state->numTaps = num_taps;
    state->pCoeffs = coefficients;
    state->pState = buffer;

    for (uint32_t index = 0U; index < (uint32_t)num_taps + block_size - 1U; index++) {
        buffer[index] = 0;
    }

    return ARM_MATH_SUCCESS;
}

void arm_fir_decimate_q15(const arm_fir_decimate_instance_q15 *state,
                          q15_t *source,
                          q15_t *destination,
                          uint32_t block_size)
{
    uint32_t state_length = (uint32_t)state->numTaps + block_size - 1U;

    for (uint32_t index = 0U; index < block_size; index++) {
        state->pState[state_length - block_size + index] = source[index];
    }

    for (uint32_t output = 0U; output < block_size / state->M; output++) {
        int64_t accumulator = 0;
        uint32_t offset = output * state->M;

        for (uint32_t tap = 0U; tap < state->numTaps; tap++) {
            accumulator += (int32_t)state->pState[offset + tap] * state->pCoeffs[tap];
        }

        accumulator >>= 15;
        if (accumulator > INT16_MAX) {
            accumulator = INT16_MAX;
        } else if (accumulator < INT16_MIN) {
            accumulator = INT16_MIN;
        }
        destination[output] = (q15_t)accumulator;
    }

    for (uint32_t index = 0U; index < (uint32_t)state->numTaps - 1U; index++) {
        state->pState[index] = state->pState[block_size + index];
    }
}
